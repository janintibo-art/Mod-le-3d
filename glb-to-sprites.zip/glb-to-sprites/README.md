# GLB → Sprites 2D (Sprite Bench)

Application qui charge un personnage **3D animé au format `.glb`**, lit ses
animations intégrées (marche, course, saut…) et **exporte les images 2D sur
fond transparent** prêtes à servir de sprites dans un jeu vidéo.

Tu choisis une animation (ex. *marche*), un angle de vue, le nombre d'images,
et l'appli te fournit :

- soit **les images PNG séparées** (un cycle complet) dans un `.zip` ;
- soit une **planche (sprite sheet) PNG + un fichier JSON** décrivant la
  position de chaque image (atlas), à importer dans ton moteur de jeu.

Le même code tourne **dans le navigateur** (le plus pratique pour bosser) et
se compile en **APK Android** automatiquement via GitHub Actions.

---

## ✨ Fonctionnalités

- Lecture des animations nommées contenues dans le `.glb` / `.gltf`.
- Aperçu **en direct** de l'animation choisie avant export.
- Fond **transparent** (ou couleur unie au choix).
- Vue réglable : face, profil, 3/4, dos, dessus… + inclinaison + zoom.
- Mode **8 directions** (idéal jeu vue de dessus / RPG).
- Mode **toutes les animations d'un coup** : capture idle, marche, course,
  saut… en une fois (× les directions choisies), avec un nombre d'images adapté
  à chaque animation.
- Résolutions 64 / 128 / 256 / 512 / 1024 px.
- Export **images séparées**, **sprite sheet + atlas JSON**, ou **ressource
  Godot 4 (SpriteFrames .tres)** prête à glisser dans un projet.
- **Aperçu avant export** : GIF animé du cycle, **slider image par image**, et
  planche montée, avec téléchargement direct.
- Sur Android : enregistrement via la **feuille de partage** du téléphone.

---

## 🗂️ Arborescence

```
glb-to-sprites/
├── index.html                  # Interface
├── src/
│   ├── main.js                 # Logique UI (aperçu, export)
│   ├── renderer.js             # Three.js : chargement GLB, caméra, capture
│   ├── exporter.js             # ZIP d'images / sprite sheet + JSON, rognage
│   ├── gifExport.js            # GIF animé du cycle (gifenc)
│   ├── godotExport.js          # Ressource Godot 4 SpriteFrames (.tres)
│   ├── save.js                 # Enregistrement web / Android (Capacitor)
│   └── style.css               # Thème
├── public/                     # Assets statiques (ex. un .glb de test)
├── capacitor.config.json       # Config app Android (appId, nom)
├── vite.config.js              # Build (base relative pour le WebView)
├── package.json
├── .github/workflows/
│   └── build-android.yml       # CI : compile l'APK
├── .gitignore
├── LICENSE
└── README.md
```

> Le dossier `android/` est **généré automatiquement** par Capacitor (en local
> ou par la CI) ; il est volontairement ignoré par git.

---

## 📁 Choisir où enregistrer le fichier

- **Ordinateur (Chrome / Edge)** : à chaque export, un vrai dialogue
  « Enregistrer sous… » s'ouvre et te laisse **choisir le dossier** et le nom.
  (Astuce : tu peux aussi activer *Paramètres → Téléchargements → « Toujours
  demander où enregistrer »* dans le navigateur.)
- **Firefox / Safari** : le fichier va dans le dossier de téléchargement par
  défaut du navigateur.
- **APK Android** : pas de sélecteur de dossier (limite d'Android sans code
  natif). Le fichier passe par la **feuille de partage** ; choisis « Fichiers »,
  Drive, ou un gestionnaire de fichiers pour l'enregistrer où tu veux, ou bien
  **ton app d'e-mail (Gmail, Outlook…)** pour te l'envoyer en pièce jointe
  (l'objet et le corps sont pré-remplis). Pour un vrai choix de dossier, utilise
  plutôt la **version web** (voir GitHub Pages).

## 🚀 Utilisation rapide (version web)

Pré-requis : [Node.js](https://nodejs.org) 18 ou plus.

```bash
npm install
npm run dev
```

Ouvre l'URL affichée (ex. `http://localhost:5173`), charge un `.glb` animé,
choisis ton animation et exporte.

### Où trouver un `.glb` animé pour tester ?

Le plus simple : **[Mixamo](https://www.mixamo.com)** (gratuit). Choisis un
personnage, applique une animation *Walking* / *Running*, puis exporte au
format **glTF Binary (.glb)** avec les *skins*. Tu obtiens un fichier
directement utilisable ici.

> **Sur Android**, le sélecteur affiche **tous les fichiers** : Android ne
> connaît pas de type MIME pour le `.glb` (il le voit comme un `.bin`), donc on
> ne filtre pas, sinon le fichier serait grisé. Sélectionne simplement ton
> `.glb` dans le gestionnaire de fichiers.

---

## 📱 Obtenir l'APK Android

### Option A — Automatique via GitHub (recommandé, sans rien installer)

1. Crée un dépôt GitHub et pousse ce projet (branche `main`).
2. L'onglet **Actions** lance le workflow *Build Android APK*.
3. À la fin, ouvre le run → section **Artifacts** → télécharge
   `glb2sprites-debug-apk`. À l'intérieur : `app-debug.apk`.
4. Installe l'APK sur ton téléphone (autorise les sources inconnues).

> C'est une APK **debug** (non signée pour le Play Store) : parfaite pour un
> usage perso ou des tests.

### Option B — En local

Pré-requis : Node.js, JDK 17, Android Studio (ou le SDK Android).

```bash
npm install
npm run build          # génère dist/
npx cap add android    # crée le dossier android/ (une seule fois)
npx cap sync android
npx cap open android   # ouvre Android Studio -> Run / Build APK
```

---

## 🎮 Importer le résultat dans un moteur de jeu

L'atlas JSON est volontairement simple :

```json
{
  "animation": "Walk",
  "direction": "front",
  "frameWidth": 168,
  "frameHeight": 240,
  "columns": 4,
  "rows": 3,
  "frameCount": 12,
  "trimmed": true,
  "sourceSize": { "w": 256, "h": 256 },
  "trim": { "x": 44, "y": 8 },
  "frames": [
    { "index": 0, "x": 0,   "y": 0, "w": 168, "h": 240 },
    { "index": 1, "x": 168, "y": 0, "w": 168, "h": 240 }
  ]
}
```

`frameWidth`/`frameHeight` correspondent à la taille **réelle** des images
(après rognage). `sourceSize` et `trim` donnent la position du recadrage dans
l'image d'origine, utile pour recaler le pivot.

- **Godot** : importe la planche PNG, crée un `SpriteFrames` / `AnimatedSprite2D`
  en découpant la grille (colonnes × lignes) — ou utilise un `AtlasTexture`.
  **Plus simple** : utilise l'export **SpriteFrames Godot (.tres)** depuis la
  fenêtre d'aperçu. Tu obtiens un `.zip` contenant un dossier à déposer à la
  racine de ton projet (`res://<dossier>/`), avec les planches et un `.tres`
  déjà prêt (une animation par direction). Glisse le `.tres` sur un
  `AnimatedSprite2D` et c'est jouable.
  En mode **toutes les animations**, le `.tres` contient **toutes les
  animations × directions** (`idle_front`, `walk_front`, `run_right`…) :
  un seul fichier pour tout le personnage. Tu changes d'état par code, ex.
  `$AnimatedSprite2D.play("walk_" + direction)`.
- **Unity** : Sprite Mode *Multiple*, *Grid By Cell Size* avec `frameWidth` /
  `frameHeight`.
- **Phaser / web** : `this.load.spritesheet(key, png, { frameWidth, frameHeight })`.

Les images séparées (mode ZIP) conviennent à n'importe quel pipeline qui
préfère des fichiers individuels.

---

## 🔧 Réglages utiles

| Réglage        | Effet |
|----------------|-------|
| Nombre d'images | Densité du cycle (ex. 8–16 pour une marche). |
| Vue / direction | Angle de capture ; *Profil* pour un platformer. |
| 8 directions   | Génère les 8 angles d'un coup (jeu vue de dessus). |
| Toutes les animations | Capture chaque animation du `.glb` en une fois (× directions). |
| Inclinaison    | Vue légèrement plongeante (style 2.5D / iso). |
| Zoom / marge   | Évite que les membres soient coupés pendant le mouvement. |
| Résolution     | Taille des images de sortie (64 px pour du pixel-art chunky). |
| Mode pixel art | Rendu net, sans anti-aliasing, filtrage *nearest* des textures. |
| Rogner les marges | Recadre sur le personnage : sprites compacts et **alignés**. |

Les images sont échantillonnées sur `[0, durée)` pour une **boucle sans
doublon** entre la dernière et la première image.

---

## 🧭 Limites & pistes d'évolution

- **Rognage** : la boîte de recadrage est commune à toutes les images (et à
  toutes les directions) pour garder une taille uniforme et un personnage qui
  ne « saute » pas. L'atlas JSON contient `sourceSize` et `trim` pour
  reconstruire le pivot d'origine si besoin.
- **Pixel art** : applique le filtrage *nearest* et coupe l'anti-aliasing.
  Combine-le avec une petite résolution (64 / 128 px) pour un rendu net.
- **GIF d'aperçu** : pratique pour partager le cycle (README GitHub, etc.).
  Le GIF est limité à une transparence 1 bit (bords parfois durs) ; pour un
  GIF impeccable, choisis un fond de **couleur unie**. Les vrais assets
  transparents restent les PNG.
- Atlas compact type TexturePacker (cellules de tailles variables) : non géré ;
  ici toutes les cellules ont la même taille (plus simple à importer).
- Lecture des `.gltf` multi-fichiers (avec `.bin`/textures séparés) :
  privilégier le `.glb` (tout-en-un) pour l'instant.

---

## Licence

MIT — voir [LICENSE](./LICENSE).
