import { SpriteRenderer, ALL_DIRECTIONS } from './renderer.js';
import { exportFramesZip, exportSheetZip, trimCaptures, buildSheetCanvas } from './exporter.js';
import { framesToGif } from './gifExport.js';
import { exportGodotZip } from './godotExport.js';
import { saveBlob } from './save.js';
import './style.css';

const $ = (id) => document.getElementById(id);

const els = {
  glbInput:   $('glbInput'),
  fileName:   $('fileName'),
  modelMeta:  $('modelMeta'),
  metaDims:   $('metaDims'),
  metaAnims:  $('metaAnims'),
  clipSelect: $('clipSelect'),
  frameCount: $('frameCount'),
  dirSelect:  $('dirSelect'),
  multiDir:   $('multiDir'),
  elevation:  $('elevation'),
  elevationVal: $('elevationVal'),
  framing:    $('framing'),
  framingVal: $('framingVal'),
  outSize:    $('outSize'),
  bgMode:     $('bgMode'),
  bgColor:    $('bgColor'),
  pixelArt:   $('pixelArt'),
  trim:       $('trim'),
  sheetCols:  $('sheetCols'),
  btnPreview: $('btnPreview'),
  btnFrames:  $('btnFrames'),
  btnSheet:   $('btnSheet'),
  stage:      $('stage'),
  log:        $('log'),
  liveDot:    $('liveDot'),
  stageLabel: $('stageLabel'),
  // modale
  modal:      $('modal'),
  modalCard:  $('modalCard'),
  modalClose: $('modalClose'),
  modalMeta:  $('modalMeta'),
  gifCell:    $('gifCell'),
  gifImg:     $('gifImg'),
  gifNote:    $('gifNote'),
  sheetHolder:$('sheetHolder'),
  dlFrames:   $('dlFrames'),
  dlSheet:    $('dlSheet'),
  dlGif:      $('dlGif'),
  dlGodot:    $('dlGodot'),
  frameCanvas:$('frameCanvas'),
  frameRange: $('frameRange'),
  frameLabel: $('frameLabel'),
};

const renderer = new SpriteRenderer(els.stage);
let modelName = 'personnage';
let ready = false;

let lastResult = null;   // { captures, bbox }
let lastGifBlob = null;
let lastGifUrl = null;
let scrubFrames = [];

const tick = () => new Promise((r) => setTimeout(r, 0));

// ----------------------------- Journal -----------------------------
function log(message, kind = '') {
  const p = document.createElement('p');
  p.className = 'log__line' + (kind ? ` log__line--${kind}` : '');
  p.innerHTML = message;
  els.log.appendChild(p);
  els.log.scrollTop = els.log.scrollHeight;
}

// ------------------------- Chargement GLB --------------------------
els.glbInput.addEventListener('change', async (e) => {
  const file = e.target.files && e.target.files[0];
  if (!file) return;

  modelName = file.name.replace(/\.(glb|gltf)$/i, '') || 'personnage';
  els.fileName.textContent = file.name;
  log(`Lecture de <code>${file.name}</code>…`);

  try {
    const buffer = await file.arrayBuffer();
    const info = await renderer.load(buffer);

    els.clipSelect.innerHTML = '';
    if (info.hasAnimations) {
      info.clips.forEach((c) => {
        const opt = document.createElement('option');
        opt.value = c.name;
        opt.textContent = `${c.name}  (${c.duration.toFixed(2)} s)`;
        els.clipSelect.appendChild(opt);
      });
      log(`${info.clips.length} animation(s) trouvée(s).`, 'ok');
    } else {
      const opt = document.createElement('option');
      opt.value = '';
      opt.textContent = 'Statique (pose par défaut)';
      els.clipSelect.appendChild(opt);
      log('Aucune animation. Export d\'une image statique possible.', 'warn');
    }

    const d = info.dims;
    els.metaDims.textContent = `${d.x.toFixed(1)} × ${d.y.toFixed(1)} × ${d.z.toFixed(1)}`;
    els.metaAnims.textContent = String(info.clips.length);
    els.modelMeta.hidden = false;

    enableControls(true);
    suggestFrameCount();
    refreshPreview();
    log('Prêt à capturer. Choisis une vue puis « Aperçu ».', 'ok');
  } catch (err) {
    console.error(err);
    log(`Échec du chargement : ${err && err.message ? err.message : err}`, 'err');
  }
});

// ------------------------ Activation UI ----------------------------
function enableControls(on) {
  ready = on;
  [
    els.clipSelect, els.frameCount, els.dirSelect, els.multiDir,
    els.elevation, els.framing, els.outSize, els.bgMode,
    els.pixelArt, els.trim, els.sheetCols,
    els.btnPreview, els.btnFrames, els.btnSheet,
  ].forEach((el) => { el.disabled = !on; });
  els.bgColor.disabled = !on || els.bgMode.value !== 'color';
}

function suggestFrameCount() {
  const opt = [...els.clipSelect.options].find((o) => o.value === els.clipSelect.value);
  if (!opt) return;
  const match = opt.textContent.match(/\(([\d.]+)\s*s\)/);
  if (!match) return;
  const dur = parseFloat(match[1]);
  els.frameCount.value = String(Math.min(48, Math.max(4, Math.round(dur * 12))));
}

function selectedDurationSec() {
  const opt = [...els.clipSelect.options].find((o) => o.value === els.clipSelect.value);
  if (!opt) return 1;
  const m = opt.textContent.match(/\(([\d.]+)\s*s\)/);
  return m ? parseFloat(m[1]) : 1;
}

// --------------------------- Aperçu live ---------------------------
function refreshPreview() {
  if (!ready) return;
  const clip = els.clipSelect.value;
  renderer.startPreview(clip);
  const playing = clip !== '';
  els.liveDot.classList.toggle('is-live', playing);
  els.stageLabel.textContent = playing ? `Aperçu : ${clip}` : 'Aperçu statique';
}

// ---------------------- Branchement contrôles ----------------------
els.clipSelect.addEventListener('change', () => { suggestFrameCount(); refreshPreview(); });

els.dirSelect.addEventListener('change', () => {
  renderer.setDirection(els.dirSelect.value);
  refreshPreview();
});

els.elevation.addEventListener('input', () => {
  els.elevationVal.textContent = `${els.elevation.value}°`;
  renderer.setElevation(parseFloat(els.elevation.value));
});

els.framing.addEventListener('input', () => {
  els.framingVal.textContent = `${parseFloat(els.framing.value).toFixed(2)}×`;
  renderer.setFraming(parseFloat(els.framing.value));
});

els.outSize.addEventListener('change', () => {
  renderer.setSize(parseInt(els.outSize.value, 10));
});

els.bgMode.addEventListener('change', () => {
  const useColor = els.bgMode.value === 'color';
  els.bgColor.disabled = !useColor;
  renderer.setBackground(useColor ? els.bgColor.value : null);
});

els.bgColor.addEventListener('input', () => {
  if (els.bgMode.value === 'color') renderer.setBackground(els.bgColor.value);
});

els.pixelArt.addEventListener('change', () => {
  renderer.setPixelArt(els.pixelArt.checked);
  els.stage.classList.toggle('is-pixel', els.pixelArt.checked);
  log(els.pixelArt.checked ? 'Mode pixel-art activé (rendu net).' : 'Mode pixel-art désactivé.');
  refreshPreview();
});

// ----------------------------- Capture -----------------------------
function targetDirections() {
  if (els.multiDir.checked && els.dirSelect.value !== 'top') return ALL_DIRECTIONS.slice();
  return [els.dirSelect.value];
}

function captureForSelectedDir(captures) {
  const dir = els.dirSelect.value;
  return captures.find((c) => c.direction === dir) || captures[0];
}

async function runCapture() {
  const clip = els.clipSelect.value;
  const frameCount = parseInt(els.frameCount.value, 10) || 1;
  const dirs = targetDirections();
  const previousDir = els.dirSelect.value;
  let captures = [];

  els.stage.classList.add('is-capturing');
  for (const dir of dirs) {
    renderer.setDirection(dir);
    log(`Capture « ${dir} » — ${frameCount} image(s)…`);
    const { frames } = await renderer.capture(clip, frameCount);
    captures.push({ direction: dir, frames });
  }
  renderer.setDirection(previousDir);
  els.stage.classList.remove('is-capturing');
  refreshPreview();

  let bbox = null;
  if (els.trim.checked) {
    const res = trimCaptures(captures, 0);
    captures = res.captures;
    bbox = res.bbox;
    log(`Rognage : ${bbox.source.w}×${bbox.source.h} → ${bbox.w}×${bbox.h} px`, 'ok');
  }
  return { captures, bbox };
}

// ------------------------- États "occupé" --------------------------
async function withBusy(button, label, fn) {
  if (!ready) return;
  const original = button.textContent;
  [els.btnPreview, els.btnFrames, els.btnSheet].forEach((b) => { b.disabled = true; });
  button.classList.add('btn--busy');
  button.textContent = label;
  try {
    await fn();
  } catch (err) {
    console.error(err);
    log(`Erreur : ${err && err.message ? err.message : err}`, 'err');
  } finally {
    button.classList.remove('btn--busy');
    button.textContent = original;
    [els.btnPreview, els.btnFrames, els.btnSheet].forEach((b) => { b.disabled = false; });
  }
}

async function clickBusy(button, fn) {
  const original = button.textContent;
  button.disabled = true;
  button.classList.add('btn--busy');
  button.textContent = 'Patiente…';
  try {
    await fn();
  } catch (err) {
    console.error(err);
    log(`Erreur : ${err && err.message ? err.message : err}`, 'err');
  } finally {
    button.classList.remove('btn--busy');
    button.textContent = original;
    button.disabled = false;
  }
}

// ----------------------------- Modale ------------------------------
function openModal() {
  els.modal.hidden = false;
  document.addEventListener('keydown', onModalKey);
}
function closeModal() {
  els.modal.hidden = true;
  document.removeEventListener('keydown', onModalKey);
}
function onModalKey(e) { if (e.key === 'Escape') closeModal(); }

els.modalClose.addEventListener('click', closeModal);
els.modal.querySelector('[data-close]').addEventListener('click', closeModal);

// Parcours image par image
function renderScrubFrame(i) {
  const f = scrubFrames[i];
  if (!f) return;
  const cv = els.frameCanvas;
  cv.width = f.width;
  cv.height = f.height;
  cv.getContext('2d').drawImage(f, 0, 0);
  els.frameLabel.textContent = `Image ${i + 1} / ${scrubFrames.length}`;
}

els.frameRange.addEventListener('input', () => {
  renderScrubFrame(parseInt(els.frameRange.value, 10));
});

async function showPreviewModal(captures, bbox) {
  const cap = captureForSelectedDir(captures);
  const cols = parseInt(els.sheetCols.value, 10) || 0;

  // Planche (immédiate)
  const { canvas } = buildSheetCanvas(cap.frames, cols);
  els.sheetHolder.innerHTML = '';
  els.sheetHolder.appendChild(canvas);

  // Scrubber image par image
  scrubFrames = cap.frames;
  els.frameRange.max = String(Math.max(0, cap.frames.length - 1));
  els.frameRange.value = '0';
  els.frameRange.disabled = cap.frames.length < 2;
  renderScrubFrame(0);

  const f0 = cap.frames[0];
  const multi = els.multiDir.checked && els.dirSelect.value !== 'top';
  els.modalMeta.textContent =
    `${els.clipSelect.value || 'statique'} · ${cap.frames.length} images · ` +
    `${f0.width}×${f0.height} px/cellule · vue ${cap.direction}` +
    (multi ? ' · téléchargement = 8 directions' : '');

  els.modalCard.classList.toggle('is-pixel', els.pixelArt.checked);
  openModal();

  // GIF (asynchrone, après l'affichage de la planche)
  els.gifImg.removeAttribute('src');
  els.gifNote.hidden = false;
  els.gifNote.textContent = 'Génération du GIF…';
  els.gifCell.classList.add('is-loading');
  els.dlGif.disabled = true;

  if (cap.frames.length > 1) {
    await tick();
    try {
      const delay = (selectedDurationSec() / cap.frames.length) * 1000;
      const gifBlob = framesToGif(cap.frames, delay);
      lastGifBlob = gifBlob;
      if (lastGifUrl) URL.revokeObjectURL(lastGifUrl);
      lastGifUrl = URL.createObjectURL(gifBlob);
      els.gifImg.src = lastGifUrl;
      els.gifNote.hidden = true;
      els.dlGif.disabled = false;
    } catch (err) {
      console.error(err);
      els.gifNote.textContent = 'GIF indisponible pour ce fichier.';
    }
  } else {
    els.gifNote.textContent = 'Animation requise pour générer un GIF.';
  }
  els.gifCell.classList.remove('is-loading');
}

// --------------------------- Boutons -------------------------------
els.btnPreview.addEventListener('click', () => withBusy(els.btnPreview, 'Capture…', async () => {
  const { captures, bbox } = await runCapture();
  lastResult = { captures, bbox };
  await showPreviewModal(captures, bbox);
}));

els.btnFrames.addEventListener('click', () => withBusy(els.btnFrames, 'Capture…', async () => {
  const { captures } = await runCapture();
  lastResult = { captures, bbox: null };
  const total = captures.reduce((s, c) => s + c.frames.length, 0);
  const blob = await exportFramesZip(captures, modelName);
  const fname = `${modelName}_${els.clipSelect.value || 'static'}_frames.zip`;
  await saveBlob(blob, fname);
  log(`${total} image(s) exportée(s) → <code>${fname}</code>`, 'ok');
}));

els.btnSheet.addEventListener('click', () => withBusy(els.btnSheet, 'Capture…', async () => {
  const { captures, bbox } = await runCapture();
  lastResult = { captures, bbox };
  const blob = await exportSheetZip(captures, modelName, {
    columns: parseInt(els.sheetCols.value, 10) || 0,
    animation: els.clipSelect.value || 'static',
    bbox,
  });
  const fname = `${modelName}_${els.clipSelect.value || 'static'}_spritesheet.zip`;
  await saveBlob(blob, fname);
  log(`Planche(s) + JSON exportée(s) → <code>${fname}</code>`, 'ok');
}));

// Téléchargements depuis la modale (réutilisent la dernière capture)
els.dlFrames.addEventListener('click', () => clickBusy(els.dlFrames, async () => {
  if (!lastResult) return;
  const blob = await exportFramesZip(lastResult.captures, modelName);
  const fname = `${modelName}_${els.clipSelect.value || 'static'}_frames.zip`;
  await saveBlob(blob, fname);
  log(`Images exportées → <code>${fname}</code>`, 'ok');
}));

els.dlSheet.addEventListener('click', () => clickBusy(els.dlSheet, async () => {
  if (!lastResult) return;
  const blob = await exportSheetZip(lastResult.captures, modelName, {
    columns: parseInt(els.sheetCols.value, 10) || 0,
    animation: els.clipSelect.value || 'static',
    bbox: lastResult.bbox,
  });
  const fname = `${modelName}_${els.clipSelect.value || 'static'}_spritesheet.zip`;
  await saveBlob(blob, fname);
  log(`Planche + JSON exportée → <code>${fname}</code>`, 'ok');
}));

els.dlGif.addEventListener('click', () => clickBusy(els.dlGif, async () => {
  if (!lastGifBlob) return;
  const fname = `${modelName}_${els.clipSelect.value || 'static'}.gif`;
  await saveBlob(lastGifBlob, fname);
  log(`GIF exporté → <code>${fname}</code>`, 'ok');
}));

els.dlGodot.addEventListener('click', () => clickBusy(els.dlGodot, async () => {
  if (!lastResult) return;
  const animSafe = sanitize(els.clipSelect.value || 'static');
  const folder = `${sanitize(modelName)}_${animSafe}`;
  const dur = selectedDurationSec();
  const n = lastResult.captures[0].frames.length;
  const fps = (n > 1 && dur > 0) ? n / dur : 12;
  const blob = await exportGodotZip(lastResult.captures, sanitize(modelName), {
    columns: parseInt(els.sheetCols.value, 10) || 0,
    animation: animSafe,
    folder,
    fps,
    loop: n > 1,
  });
  const fname = `${folder}_godot.zip`;
  await saveBlob(blob, fname);
  log(`SpriteFrames Godot exporté → <code>${fname}</code>`, 'ok');
}));

function sanitize(s) {
  return (s || '').replace(/[^\w-]+/g, '_').replace(/^_+|_+$/g, '') || 'sprite';
}
