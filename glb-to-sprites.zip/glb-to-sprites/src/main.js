import { SpriteRenderer, ALL_DIRECTIONS } from './renderer.js';
import { exportFramesZip, exportSheetZip, trimUnits, buildSheetCanvas } from './exporter.js';
import { framesToGif } from './gifExport.js';
import { exportGodotZip } from './godotExport.js';
import { beginSave, finishSave } from './save.js';
import './style.css';

const $ = (id) => document.getElementById(id);

const els = {
  glbInput:   $('glbInput'),
  fileName:   $('fileName'),
  modelMeta:  $('modelMeta'),
  metaDims:   $('metaDims'),
  metaAnims:  $('metaAnims'),
  clipSelect: $('clipSelect'),
  frameCount: $('frameCount'),
  allAnims:   $('allAnims'),
  dirSelect:  $('dirSelect'),
  multiDir:   $('multiDir'),
  elevation:  $('elevation'),
  elevationVal: $('elevationVal'),
  framing:    $('framing'),
  framingVal: $('framingVal'),
  outSize:    $('outSize'),
  bgMode:     $('bgMode'),
  bgColor:    $('bgColor'),
  pixelArt:   $('pixelArt'),
  trim:       $('trim'),
  sheetCols:  $('sheetCols'),
  btnPreview: $('btnPreview'),
  btnFrames:  $('btnFrames'),
  btnSheet:   $('btnSheet'),
  stage:      $('stage'),
  log:        $('log'),
  liveDot:    $('liveDot'),
  stageLabel: $('stageLabel'),
  modal:      $('modal'),
  modalCard:  $('modalCard'),
  modalClose: $('modalClose'),
  modalMeta:  $('modalMeta'),
  gifCell:    $('gifCell'),
  gifImg:     $('gifImg'),
  gifNote:    $('gifNote'),
  sheetHolder:$('sheetHolder'),
  modalStatus:$('modalStatus'),
  dlFrames:   $('dlFrames'),
  dlSheet:    $('dlSheet'),
  dlGif:      $('dlGif'),
  dlGodot:    $('dlGodot'),
  frameCanvas:$('frameCanvas'),
  frameRange: $('frameRange'),
  frameLabel: $('frameLabel'),
};

const renderer = new SpriteRenderer(els.stage);
let modelName = 'personnage';
let ready = false;
let clipDurations = {};

let lastResult = null;   // { units, bbox, batch }
let lastGifBlob = null;
let lastGifUrl = null;
let scrubFrames = [];

const tick = () => new Promise((r) => setTimeout(r, 0));

// ----------------------------- Journal -----------------------------
function log(message, kind = '') {
  const p = document.createElement('p');
  p.className = 'log__line' + (kind ? ` log__line--${kind}` : '');
  p.innerHTML = message;
  els.log.appendChild(p);
  els.log.scrollTop = els.log.scrollHeight;
}

// ------------------------- Chargement GLB --------------------------
els.glbInput.addEventListener('change', async (e) => {
  const file = e.target.files && e.target.files[0];
  if (!file) return;

  const lower = file.name.toLowerCase();
  if (!lower.endsWith('.glb') && !lower.endsWith('.gltf')) {
    log(`« ${file.name} » n'a pas l'extension .glb/.gltf — lecture quand même…`, 'warn');
  }

  modelName = file.name.replace(/\.(glb|gltf)$/i, '') || 'personnage';
  els.fileName.textContent = file.name;
  log(`Lecture de <code>${file.name}</code>…`);

  try {
    const buffer = await file.arrayBuffer();
    const info = await renderer.load(buffer);

    clipDurations = {};
    els.clipSelect.innerHTML = '';
    if (info.hasAnimations) {
      info.clips.forEach((c) => {
        clipDurations[c.name] = c.duration;
        const opt = document.createElement('option');
        opt.value = c.name;
        opt.textContent = `${c.name}  (${c.duration.toFixed(2)} s)`;
        els.clipSelect.appendChild(opt);
      });
      log(`${info.clips.length} animation(s) trouvée(s).`, 'ok');
    } else {
      const opt = document.createElement('option');
      opt.value = '';
      opt.textContent = 'Statique (pose par défaut)';
      els.clipSelect.appendChild(opt);
      log('Aucune animation. Export d\'une image statique possible.', 'warn');
    }

    const d = info.dims;
    els.metaDims.textContent = `${d.x.toFixed(1)} × ${d.y.toFixed(1)} × ${d.z.toFixed(1)}`;
    els.metaAnims.textContent = String(info.clips.length);
    els.modelMeta.hidden = false;

    enableControls(true);
    // "Toutes les animations" n'a de sens que s'il y en a plusieurs
    els.allAnims.disabled = info.clips.length < 2;
    if (els.allAnims.disabled) els.allAnims.checked = false;

    suggestFrameCount();
    refreshPreview();
    log('Prêt à capturer. Choisis une vue puis « Aperçu ».', 'ok');
  } catch (err) {
    console.error(err);
    log(`Échec du chargement : ${err && err.message ? err.message : err}`, 'err');
  }
});

// ------------------------ Activation UI ----------------------------
function enableControls(on) {
  ready = on;
  [
    els.clipSelect, els.frameCount, els.allAnims, els.dirSelect, els.multiDir,
    els.elevation, els.framing, els.outSize, els.bgMode,
    els.pixelArt, els.trim, els.sheetCols,
    els.btnPreview, els.btnFrames, els.btnSheet,
  ].forEach((el) => { el.disabled = !on; });
  els.bgColor.disabled = !on || els.bgMode.value !== 'color';
}

function suggestFrameCount() {
  const opt = [...els.clipSelect.options].find((o) => o.value === els.clipSelect.value);
  if (!opt) return;
  const dur = clipDurations[els.clipSelect.value];
  if (dur == null) return;
  els.frameCount.value = String(framesFromDuration(dur));
}

function framesFromDuration(dur) {
  return Math.min(48, Math.max(4, Math.round(dur * 12)));
}

function selectedDurationSec() {
  return clipDurations[els.clipSelect.value] || 1;
}

// --------------------------- Aperçu live ---------------------------
function refreshPreview() {
  if (!ready) return;
  const clip = els.clipSelect.value;
  renderer.startPreview(clip);
  const playing = clip !== '';
  els.liveDot.classList.toggle('is-live', playing);
  els.stageLabel.textContent = playing ? `Aperçu : ${clip}` : 'Aperçu statique';
}

// ---------------------- Branchement contrôles ----------------------
els.clipSelect.addEventListener('change', () => { suggestFrameCount(); refreshPreview(); });

els.dirSelect.addEventListener('change', () => {
  renderer.setDirection(els.dirSelect.value);
  refreshPreview();
});

els.elevation.addEventListener('input', () => {
  els.elevationVal.textContent = `${els.elevation.value}°`;
  renderer.setElevation(parseFloat(els.elevation.value));
});

els.framing.addEventListener('input', () => {
  els.framingVal.textContent = `${parseFloat(els.framing.value).toFixed(2)}×`;
  renderer.setFraming(parseFloat(els.framing.value));
});

els.outSize.addEventListener('change', () => {
  renderer.setSize(parseInt(els.outSize.value, 10));
});

els.bgMode.addEventListener('change', () => {
  const useColor = els.bgMode.value === 'color';
  els.bgColor.disabled = !useColor;
  renderer.setBackground(useColor ? els.bgColor.value : null);
});

els.bgColor.addEventListener('input', () => {
  if (els.bgMode.value === 'color') renderer.setBackground(els.bgColor.value);
});

els.pixelArt.addEventListener('change', () => {
  renderer.setPixelArt(els.pixelArt.checked);
  els.stage.classList.toggle('is-pixel', els.pixelArt.checked);
  log(els.pixelArt.checked ? 'Mode pixel-art activé (rendu net).' : 'Mode pixel-art désactivé.');
  refreshPreview();
});

// ----------------------------- Capture -----------------------------
function targetDirections() {
  if (els.multiDir.checked && els.dirSelect.value !== 'top') return ALL_DIRECTIONS.slice();
  return [els.dirSelect.value];
}

function allClipNames() {
  const names = [...els.clipSelect.options].map((o) => o.value).filter((v) => v !== '');
  return names.length ? names : [''];
}

function framesForClip(clipName, batch) {
  if (!batch) return parseInt(els.frameCount.value, 10) || 1;
  if (!clipName) return parseInt(els.frameCount.value, 10) || 1;
  return framesFromDuration(clipDurations[clipName] || 1);
}

async function runCapture() {
  const batch = els.allAnims.checked && !els.allAnims.disabled;
  const clipNames = batch ? allClipNames() : [els.clipSelect.value];
  const dirs = targetDirections();
  const previousDir = els.dirSelect.value;
  let units = [];

  els.stage.classList.add('is-capturing');
  for (const clipName of clipNames) {
    const fc = framesForClip(clipName, batch);
    for (const dir of dirs) {
      renderer.setDirection(dir);
      log(`Capture « ${clipName || 'statique'} » / « ${dir} » — ${fc} img…`);
      const { frames } = await renderer.capture(clipName, fc);
      units.push({ animation: clipName || 'static', direction: dir, frames });
      await tick(); // laisse l'UI respirer pendant les gros lots
    }
  }
  renderer.setDirection(previousDir);
  els.stage.classList.remove('is-capturing');
  refreshPreview();

  let bbox = null;
  if (els.trim.checked) {
    const res = trimUnits(units, 0);
    units = res.units;
    bbox = res.bbox;
    log(`Rognage : ${bbox.source.w}×${bbox.source.h} → ${bbox.w}×${bbox.h} px`, 'ok');
  }
  return { units, bbox, batch };
}

// ------------------------- États "occupé" --------------------------
async function withBusy(button, label, fn) {
  if (!ready) return;
  const original = button.textContent;
  [els.btnPreview, els.btnFrames, els.btnSheet].forEach((b) => { b.disabled = true; });
  button.classList.add('btn--busy');
  button.textContent = label;
  try {
    await fn();
  } catch (err) {
    console.error(err);
    log(`Erreur : ${err && err.message ? err.message : err}`, 'err');
  } finally {
    button.classList.remove('btn--busy');
    button.textContent = original;
    [els.btnPreview, els.btnFrames, els.btnSheet].forEach((b) => { b.disabled = false; });
  }
}

async function clickBusy(button, fn) {
  const original = button.textContent;
  button.disabled = true;
  button.classList.add('btn--busy');
  button.textContent = 'Patiente…';
  try {
    await fn();
  } catch (err) {
    console.error(err);
    const m = `Erreur : ${err && err.message ? err.message : err}`;
    log(m, 'err');
    if (!els.modal.hidden) setModalStatus(m, 'err');
  } finally {
    button.classList.remove('btn--busy');
    button.textContent = original;
    button.disabled = false;
  }
}

function setModalStatus(msg, kind) {
  els.modalStatus.textContent = msg || '';
  els.modalStatus.classList.remove('is-ok', 'is-err');
  if (kind === 'ok') els.modalStatus.classList.add('is-ok');
  if (kind === 'err') els.modalStatus.classList.add('is-err');
}

function savedMessage(method) {
  if (method === 'share') return 'Partage ouvert ✓ — choisis Fichiers, Drive ou Gmail';
  if (method === 'picker') return 'Enregistré ✓';
  return 'Téléchargé ✓';
}

// ----------------------------- Modale ------------------------------
function openModal() {
  els.modal.hidden = false;
  document.addEventListener('keydown', onModalKey);
}
function closeModal() {
  els.modal.hidden = true;
  document.removeEventListener('keydown', onModalKey);
}
function onModalKey(e) { if (e.key === 'Escape') closeModal(); }

els.modalClose.addEventListener('click', closeModal);
els.modal.querySelector('[data-close]').addEventListener('click', closeModal);

function renderScrubFrame(i) {
  const f = scrubFrames[i];
  if (!f) return;
  const cv = els.frameCanvas;
  cv.width = f.width;
  cv.height = f.height;
  cv.getContext('2d').drawImage(f, 0, 0);
  els.frameLabel.textContent = `Image ${i + 1} / ${scrubFrames.length}`;
}

els.frameRange.addEventListener('input', () => {
  renderScrubFrame(parseInt(els.frameRange.value, 10));
});

async function showPreviewModal(units, batch) {
  const selAnim = els.clipSelect.value || 'static';
  const selDir = els.dirSelect.value;
  const cap = units.find((u) => u.animation === selAnim && u.direction === selDir)
    || units.find((u) => u.animation === selAnim)
    || units[0];
  const cols = parseInt(els.sheetCols.value, 10) || 0;

  // Planches : celles de l'animation sélectionnée (toutes ses directions)
  const shown = units.filter((u) => u.animation === selAnim);
  els.sheetHolder.innerHTML = '';
  for (const u of shown) {
    const { canvas } = buildSheetCanvas(u.frames, cols);
    const item = document.createElement('div');
    item.className = 'sheet-item';
    const label = document.createElement('div');
    label.className = 'sheet-item__label';
    label.textContent = `${u.direction} · ${u.frames.length} img`;
    item.appendChild(label);
    item.appendChild(canvas);
    els.sheetHolder.appendChild(item);
  }

  // Scrubber (unité sélectionnée)
  scrubFrames = cap.frames;
  els.frameRange.max = String(Math.max(0, cap.frames.length - 1));
  els.frameRange.value = '0';
  els.frameRange.disabled = cap.frames.length < 2;
  renderScrubFrame(0);

  const animCount = new Set(units.map((u) => u.animation)).size;
  const dirCount = new Set(units.map((u) => u.direction)).size;
  els.modalMeta.textContent = batch
    ? `Toutes les animations : ${animCount} animations × ${dirCount} direction(s) = ${units.length} planches. Aperçu : « ${selAnim} ».`
    : `${selAnim} · ${cap.frames.length} images · ${cap.frames[0].width}×${cap.frames[0].height} px · ` +
      (dirCount > 1 ? `${dirCount} directions` : `vue ${cap.direction}`);

  els.modalCard.classList.toggle('is-pixel', els.pixelArt.checked);
  setModalStatus('');
  openModal();

  // GIF de l'unité sélectionnée
  els.gifImg.removeAttribute('src');
  els.gifNote.hidden = false;
  els.gifNote.textContent = 'Génération du GIF…';
  els.gifCell.classList.add('is-loading');
  els.dlGif.disabled = true;

  if (cap.frames.length > 1) {
    await tick();
    try {
      const dur = clipDurations[selAnim] || 1;
      const delay = (dur / cap.frames.length) * 1000;
      const gifBlob = framesToGif(cap.frames, delay);
      lastGifBlob = gifBlob;
      if (lastGifUrl) URL.revokeObjectURL(lastGifUrl);
      lastGifUrl = URL.createObjectURL(gifBlob);
      els.gifImg.src = lastGifUrl;
      els.gifNote.hidden = true;
      els.dlGif.disabled = false;
    } catch (err) {
      console.error(err);
      els.gifNote.textContent = 'GIF indisponible pour ce fichier.';
    }
  } else {
    els.gifNote.textContent = 'Animation requise pour générer un GIF.';
  }
  els.gifCell.classList.remove('is-loading');
}

// --------------------------- Helpers export ------------------------
function sanitize(s) {
  return (s || '').replace(/[^\w-]+/g, '_').replace(/^_+|_+$/g, '') || 'sprite';
}

function exportLabel() {
  return (lastResult && lastResult.batch) ? 'all' : (els.clipSelect.value || 'static');
}

// --------------------------- Boutons -------------------------------
els.btnPreview.addEventListener('click', () => withBusy(els.btnPreview, 'Capture…', async () => {
  const { units, bbox, batch } = await runCapture();
  lastResult = { units, bbox, batch };
  await showPreviewModal(units, batch);
}));

els.btnFrames.addEventListener('click', () => withBusy(els.btnFrames, 'Capture…', async () => {
  const batch = els.allAnims.checked && !els.allAnims.disabled;
  const fname = `${modelName}_${batch ? 'all' : (els.clipSelect.value || 'static')}_frames.zip`;
  const target = await beginSave(fname);
  if (target.cancelled) return;
  const { units } = await runCapture();
  lastResult = { units, bbox: null, batch };
  const total = units.reduce((s, u) => s + u.frames.length, 0);
  const blob = await exportFramesZip(units, modelName);
  await finishSave(target.handle, blob, fname);
  log(`${total} image(s) exportée(s) → <code>${fname}</code>`, 'ok');
}));

els.btnSheet.addEventListener('click', () => withBusy(els.btnSheet, 'Capture…', async () => {
  const batch = els.allAnims.checked && !els.allAnims.disabled;
  const fname = `${modelName}_${batch ? 'all' : (els.clipSelect.value || 'static')}_spritesheet.zip`;
  const target = await beginSave(fname);
  if (target.cancelled) return;
  const { units, bbox } = await runCapture();
  lastResult = { units, bbox, batch };
  const blob = await exportSheetZip(units, modelName, {
    columns: parseInt(els.sheetCols.value, 10) || 0,
    bbox,
  });
  await finishSave(target.handle, blob, fname);
  log(`Planche(s) + JSON exportée(s) → <code>${fname}</code>`, 'ok');
}));

// Téléchargements depuis la modale (réutilisent la dernière capture)
els.dlFrames.addEventListener('click', () => clickBusy(els.dlFrames, async () => {
  if (!lastResult) return;
  setModalStatus('Préparation du ZIP…');
  const fname = `${modelName}_${exportLabel()}_frames.zip`;
  const target = await beginSave(fname);
  if (target.cancelled) { setModalStatus(''); return; }
  const blob = await exportFramesZip(lastResult.units, modelName, (d, t) => setModalStatus(`Compression… ${d}/${t}`));
  setModalStatus('Enregistrement…');
  const method = await finishSave(target.handle, blob, fname);
  setModalStatus(savedMessage(method), 'ok');
  log(`Images exportées → <code>${fname}</code>`, 'ok');
}));

els.dlSheet.addEventListener('click', () => clickBusy(els.dlSheet, async () => {
  if (!lastResult) return;
  setModalStatus('Préparation des planches…');
  const fname = `${modelName}_${exportLabel()}_spritesheet.zip`;
  const target = await beginSave(fname);
  if (target.cancelled) { setModalStatus(''); return; }
  const blob = await exportSheetZip(lastResult.units, modelName, {
    columns: parseInt(els.sheetCols.value, 10) || 0,
    bbox: lastResult.bbox,
  }, (d, t) => setModalStatus(`Planches… ${d}/${t}`));
  setModalStatus('Enregistrement…');
  const method = await finishSave(target.handle, blob, fname);
  setModalStatus(savedMessage(method), 'ok');
  log(`Planche + JSON exportée → <code>${fname}</code>`, 'ok');
}));

els.dlGif.addEventListener('click', () => clickBusy(els.dlGif, async () => {
  if (!lastGifBlob) return;
  setModalStatus('Enregistrement du GIF…');
  const fname = `${modelName}_${els.clipSelect.value || 'static'}.gif`;
  const target = await beginSave(fname);
  if (target.cancelled) { setModalStatus(''); return; }
  const method = await finishSave(target.handle, lastGifBlob, fname);
  setModalStatus(savedMessage(method), 'ok');
  log(`GIF exporté → <code>${fname}</code>`, 'ok');
}));

els.dlGodot.addEventListener('click', () => clickBusy(els.dlGodot, async () => {
  if (!lastResult) return;
  setModalStatus('Préparation Godot…');
  const folder = `${sanitize(modelName)}_${exportLabel()}`;
  const fname = `${folder}_godot.zip`;
  const target = await beginSave(fname);
  if (target.cancelled) { setModalStatus(''); return; }
  const blob = await exportGodotZip(lastResult.units, sanitize(modelName), {
    columns: parseInt(els.sheetCols.value, 10) || 0,
    folder,
    durations: clipDurations,
    defaultFps: 12,
  }, (d, t) => setModalStatus(`Planches… ${d}/${t}`));
  setModalStatus('Enregistrement…');
  const method = await finishSave(target.handle, blob, fname);
  setModalStatus(savedMessage(method), 'ok');
  log(`SpriteFrames Godot exporté → <code>${fname}</code>`, 'ok');
}));
