import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';

const SMALL_FILE = 6 * 1024 * 1024; // 6 Mo : en dessous, partage direct sans disque

/**
 * Sélecteur "Enregistrer sous…" — uniquement sur ordinateur (Chrome/Edge).
 * JAMAIS sur natif : certains WebView Android l'exposent mais il échoue.
 */
export async function beginSave(filename) {
  const isNative = Capacitor && typeof Capacitor.isNativePlatform === 'function' && Capacitor.isNativePlatform();
  if (!isNative && typeof window !== 'undefined' && typeof window.showSaveFilePicker === 'function') {
    try {
      const handle = await window.showSaveFilePicker({
        suggestedName: filename,
        types: pickerTypes(filename),
      });
      return { cancelled: false, handle };
    } catch (err) {
      if (err && err.name === 'AbortError') return { cancelled: true, handle: null };
      console.warn('Sélecteur indisponible, repli.', err);
      return { cancelled: false, handle: null };
    }
  }
  return { cancelled: false, handle: null };
}

/**
 * Écrit / partage le blob. onPhase(phase, frac?) signale l'étape :
 * 'write' (frac 0-1) | 'share' | 'download'.
 * Renvoie 'picker' | 'share' | 'download'.
 */
export async function finishSave(handle, blob, filename, onPhase) {
  if (handle) {
    if (onPhase) onPhase('write');
    const writable = await handle.createWritable();
    await writable.write(blob);
    await writable.close();
    return 'picker';
  }
  return saveBlob(blob, filename, onPhase);
}

export async function saveBlob(blob, filename, onPhase) {
  const type = mimeFor(filename);
  const isNative = Capacitor && typeof Capacitor.isNativePlatform === 'function' && Capacitor.isNativePlatform();

  // 1) Petits fichiers : partage Web direct, sans écrire sur le disque.
  if (blob.size <= SMALL_FILE) {
    try {
      const file = new File([blob], filename, { type });
      if (navigator.canShare && navigator.canShare({ files: [file] })) {
        if (onPhase) onPhase('share');
        await navigator.share({ files: [file], title: `Sprites — ${filename}` });
        return 'share';
      }
    } catch (err) {
      if (isCancel(err)) return 'share';
      // sinon : repli ci-dessous
    }
  }

  // 2) Android : écriture PAR MORCEAUX (mémoire légère) puis partage natif.
  if (isNative) {
    const uri = await writeBlobChunked(blob, filename, (done, total) => {
      if (onPhase) onPhase('write', total ? done / total : 0);
    });
    if (onPhase) onPhase('share');
    try {
      await Share.share({
        title: `Sprites — ${filename}`,
        text: 'Sprites exportés depuis Sprite Bench (GLB → 2D). Fichier en pièce jointe.',
        url: uri,
        dialogTitle: 'Envoyer par e-mail, enregistrer ou partager',
      });
    } catch (err) {
      if (!isCancel(err)) throw err;
    }
    return 'share';
  }

  // 3) Web : téléchargement classique.
  if (onPhase) onPhase('download');
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
  return 'download';
}

/**
 * Écrit le blob dans le cache par tranches de 512 Ko. On lit le blob tranche
 * par tranche (slice) pour ne jamais charger tout le fichier en RAM, et chaque
 * tranche est écrite via Filesystem (base64 court). Évite les plantages mémoire.
 */
async function writeBlobChunked(blob, filename, onProgress) {
  const total = blob.size;
  const CHUNK = 512 * 1024;
  let offset = 0;
  let first = true;

  while (offset < total) {
    const end = Math.min(offset + CHUNK, total);
    const buf = new Uint8Array(await blob.slice(offset, end).arrayBuffer());
    const data = uint8ToBase64(buf);
    if (first) {
      await Filesystem.writeFile({ path: filename, data, directory: Directory.Cache, recursive: true });
      first = false;
    } else {
      await Filesystem.appendFile({ path: filename, data, directory: Directory.Cache });
    }
    offset = end;
    if (onProgress) onProgress(offset, total);
  }

  const { uri } = await Filesystem.getUri({ path: filename, directory: Directory.Cache });
  return uri;
}

function uint8ToBase64(bytes) {
  let binary = '';
  const SUB = 0x8000;
  for (let i = 0; i < bytes.length; i += SUB) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + SUB));
  }
  return btoa(binary);
}

function pickerTypes(filename) {
  const lower = filename.toLowerCase();
  if (lower.endsWith('.zip')) return [{ description: 'Archive ZIP', accept: { 'application/zip': ['.zip'] } }];
  if (lower.endsWith('.gif')) return [{ description: 'GIF animé', accept: { 'image/gif': ['.gif'] } }];
  if (lower.endsWith('.png')) return [{ description: 'Image PNG', accept: { 'image/png': ['.png'] } }];
  return [];
}

function mimeFor(filename) {
  const l = filename.toLowerCase();
  if (l.endsWith('.zip')) return 'application/zip';
  if (l.endsWith('.gif')) return 'image/gif';
  if (l.endsWith('.png')) return 'image/png';
  return 'application/octet-stream';
}

function isCancel(err) {
  if (!err) return false;
  if (err.name === 'AbortError') return true;
  const m = String(err.message || '').toLowerCase();
  return m.includes('cancel') || m.includes('annul') || m.includes('abort');
}
