import { Capacitor } from '@capacitor/core';

/**
 * Choisit la destination AVANT de générer le fichier (doit être appelé en
 * réponse directe à un clic, sinon le navigateur refuse le sélecteur).
 *  - Chrome / Edge (ordinateur) : vrai dialogue « Enregistrer sous… »
 *    où l'utilisateur choisit le dossier.
 *  - Ailleurs (Android, Firefox, Safari) : renvoie handle = null → on
 *    retombe sur le partage / téléchargement classique.
 * Renvoie { cancelled, handle }.
 */
export async function beginSave(filename) {
  if (typeof window !== 'undefined' && typeof window.showSaveFilePicker === 'function') {
    try {
      const handle = await window.showSaveFilePicker({
        suggestedName: filename,
        types: pickerTypes(filename),
      });
      return { cancelled: false, handle };
    } catch (err) {
      if (err && err.name === 'AbortError') return { cancelled: true, handle: null };
      console.warn('Sélecteur de fichier indisponible, repli sur le téléchargement.', err);
      return { cancelled: false, handle: null };
    }
  }
  return { cancelled: false, handle: null };
}

/** Écrit le blob : dans le handle choisi si présent, sinon repli (saveBlob). */
export async function finishSave(handle, blob, filename) {
  if (handle) {
    const writable = await handle.createWritable();
    await writable.write(blob);
    await writable.close();
    return filename;
  }
  return saveBlob(blob, filename);
}

function pickerTypes(filename) {
  const lower = filename.toLowerCase();
  if (lower.endsWith('.zip')) return [{ description: 'Archive ZIP', accept: { 'application/zip': ['.zip'] } }];
  if (lower.endsWith('.gif')) return [{ description: 'GIF animé', accept: { 'image/gif': ['.gif'] } }];
  if (lower.endsWith('.png')) return [{ description: 'Image PNG', accept: { 'image/png': ['.png'] } }];
  return [];
}

/**
 * Repli d'enregistrement (sans choix de dossier) :
 *  - Web      : téléchargement classique (dossier par défaut du navigateur).
 *  - Android  : écrit dans le cache puis ouvre la feuille de partage.
 */
export async function saveBlob(blob, filename) {
  const isNative = Capacitor && typeof Capacitor.isNativePlatform === 'function' && Capacitor.isNativePlatform();

  if (isNative) {
    const { Filesystem, Directory } = await import('@capacitor/filesystem');
    const { Share } = await import('@capacitor/share');
    const base64 = await blobToBase64(blob);
    const res = await Filesystem.writeFile({
      path: filename,
      data: base64,
      directory: Directory.Cache,
      recursive: true,
    });
    try {
      await Share.share({
        title: `Sprites — ${filename}`,
        text: 'Sprites exportés depuis Sprite Bench (GLB → 2D). Fichier en pièce jointe.',
        url: res.uri,
        dialogTitle: 'Envoyer par e-mail, enregistrer ou partager',
      });
    } catch (_e) {
      // partage annulé par l'utilisateur : le fichier reste dans le cache.
    }
    return res.uri;
  }

  // --- Web ---
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
  return filename;
}

function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = reader.result;
      resolve(typeof result === 'string' ? result.split(',')[1] : '');
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}
