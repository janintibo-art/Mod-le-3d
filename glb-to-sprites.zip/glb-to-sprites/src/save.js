import { Capacitor } from '@capacitor/core';

/**
 * Enregistre un Blob.
 *  - Web      : téléchargement classique.
 *  - Android  : écrit le fichier dans le cache puis ouvre la feuille de
 *               partage (l'utilisateur choisit où l'enregistrer).
 */
export async function saveBlob(blob, filename) {
  const isNative = Capacitor && typeof Capacitor.isNativePlatform === 'function' && Capacitor.isNativePlatform();

  if (isNative) {
    const { Filesystem, Directory } = await import('@capacitor/filesystem');
    const { Share } = await import('@capacitor/share');
    const base64 = await blobToBase64(blob);
    const res = await Filesystem.writeFile({
      path: filename,
      data: base64,
      directory: Directory.Cache,
      recursive: true,
    });
    try {
      await Share.share({ title: filename, url: res.uri });
    } catch (_e) {
      // partage annulé par l'utilisateur : le fichier reste dans le cache.
    }
    return res.uri;
  }

  // --- Web ---
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
  return filename;
}

function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = reader.result;
      resolve(typeof result === 'string' ? result.split(',')[1] : '');
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}
