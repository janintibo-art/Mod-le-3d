import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';

/**
 * Choisit la destination AVANT de générer le fichier (réponse directe au clic).
 * Chrome/Edge ordinateur → « Enregistrer sous… ». Ailleurs → handle null.
 */
export async function beginSave(filename) {
  if (typeof window !== 'undefined' && typeof window.showSaveFilePicker === 'function') {
    try {
      const handle = await window.showSaveFilePicker({
        suggestedName: filename,
        types: pickerTypes(filename),
      });
      return { cancelled: false, handle };
    } catch (err) {
      if (err && err.name === 'AbortError') return { cancelled: true, handle: null };
      console.warn('Sélecteur indisponible, repli.', err);
      return { cancelled: false, handle: null };
    }
  }
  return { cancelled: false, handle: null };
}

/**
 * Écrit / partage le blob. onPhase(phase) signale l'étape :
 * 'share' | 'write' | 'download'. Renvoie 'picker' | 'share' | 'download'.
 */
export async function finishSave(handle, blob, filename, onPhase) {
  if (handle) {
    if (onPhase) onPhase('write');
    const writable = await handle.createWritable();
    await writable.write(blob);
    await writable.close();
    return 'picker';
  }
  return saveBlob(blob, filename, onPhase);
}

export async function saveBlob(blob, filename, onPhase) {
  const type = mimeFor(filename);

  // 1) Partage Web niveau 2 : envoie le fichier SANS l'écrire sur disque.
  //    Marche dans le WebView Android récent, et évite le pont base64.
  try {
    const file = new File([blob], filename, { type });
    if (navigator.canShare && navigator.canShare({ files: [file] })) {
      if (onPhase) onPhase('share');
      await navigator.share({ files: [file], title: `Sprites — ${filename}` });
      return 'share';
    }
  } catch (err) {
    if (isCancel(err)) return 'share';
    // sinon : geste expiré ou non supporté -> on tente le repli ci-dessous.
  }

  // 2) Repli Android natif : écriture dans le cache + partage Capacitor.
  const isNative = Capacitor && typeof Capacitor.isNativePlatform === 'function' && Capacitor.isNativePlatform();
  if (isNative) {
    if (onPhase) onPhase('write');
    const base64 = await blobToBase64(blob);
    const res = await Filesystem.writeFile({
      path: filename,
      data: base64,
      directory: Directory.Cache,
      recursive: true,
    });
    if (onPhase) onPhase('share');
    try {
      await Share.share({
        title: `Sprites — ${filename}`,
        text: 'Sprites exportés depuis Sprite Bench (GLB → 2D). Fichier en pièce jointe.',
        url: res.uri,
        dialogTitle: 'Envoyer par e-mail, enregistrer ou partager',
      });
    } catch (err) {
      if (!isCancel(err)) throw err;
    }
    return 'share';
  }

  // 3) Web classique : téléchargement.
  if (onPhase) onPhase('download');
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
  return 'download';
}

function pickerTypes(filename) {
  const lower = filename.toLowerCase();
  if (lower.endsWith('.zip')) return [{ description: 'Archive ZIP', accept: { 'application/zip': ['.zip'] } }];
  if (lower.endsWith('.gif')) return [{ description: 'GIF animé', accept: { 'image/gif': ['.gif'] } }];
  if (lower.endsWith('.png')) return [{ description: 'Image PNG', accept: { 'image/png': ['.png'] } }];
  return [];
}

function mimeFor(filename) {
  const l = filename.toLowerCase();
  if (l.endsWith('.zip')) return 'application/zip';
  if (l.endsWith('.gif')) return 'image/gif';
  if (l.endsWith('.png')) return 'image/png';
  return 'application/octet-stream';
}

function isCancel(err) {
  if (!err) return false;
  if (err.name === 'AbortError') return true;
  const m = String(err.message || '').toLowerCase();
  return m.includes('cancel') || m.includes('annul') || m.includes('abort');
}

function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = reader.result;
      resolve(typeof result === 'string' ? result.split(',')[1] : '');
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}
