import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';

/**
 * Choisit la destination AVANT de générer le fichier (doit être appelé en
 * réponse directe à un clic). Ordinateur Chrome/Edge → vrai « Enregistrer
 * sous… ». Ailleurs → handle null (repli).
 * Renvoie { cancelled, handle }.
 */
export async function beginSave(filename) {
  if (typeof window !== 'undefined' && typeof window.showSaveFilePicker === 'function') {
    try {
      const handle = await window.showSaveFilePicker({
        suggestedName: filename,
        types: pickerTypes(filename),
      });
      return { cancelled: false, handle };
    } catch (err) {
      if (err && err.name === 'AbortError') return { cancelled: true, handle: null };
      console.warn('Sélecteur de fichier indisponible, repli sur le téléchargement.', err);
      return { cancelled: false, handle: null };
    }
  }
  return { cancelled: false, handle: null };
}

/** Écrit le blob. Renvoie la méthode utilisée : 'picker' | 'share' | 'download'. */
export async function finishSave(handle, blob, filename) {
  if (handle) {
    const writable = await handle.createWritable();
    await writable.write(blob);
    await writable.close();
    return 'picker';
  }
  return saveBlob(blob, filename);
}

function pickerTypes(filename) {
  const lower = filename.toLowerCase();
  if (lower.endsWith('.zip')) return [{ description: 'Archive ZIP', accept: { 'application/zip': ['.zip'] } }];
  if (lower.endsWith('.gif')) return [{ description: 'GIF animé', accept: { 'image/gif': ['.gif'] } }];
  if (lower.endsWith('.png')) return [{ description: 'Image PNG', accept: { 'image/png': ['.png'] } }];
  return [];
}

/**
 * Repli d'enregistrement. Renvoie 'share' (Android) ou 'download' (web).
 *  - Android : écrit dans le cache puis ouvre la feuille de partage
 *    (e-mail, Drive, gestionnaire de fichiers…).
 *  - Web : téléchargement classique.
 */
export async function saveBlob(blob, filename) {
  const isNative = Capacitor && typeof Capacitor.isNativePlatform === 'function' && Capacitor.isNativePlatform();

  if (isNative) {
    const base64 = await blobToBase64(blob);
    const res = await Filesystem.writeFile({
      path: filename,
      data: base64,
      directory: Directory.Cache,
      recursive: true,
    });
    try {
      await Share.share({
        title: `Sprites — ${filename}`,
        text: 'Sprites exportés depuis Sprite Bench (GLB → 2D). Fichier en pièce jointe.',
        url: res.uri,
        dialogTitle: 'Envoyer par e-mail, enregistrer ou partager',
      });
    } catch (err) {
      // Le partage annulé par l'utilisateur n'est pas une vraie erreur.
      const msg = (err && err.message ? String(err.message) : '').toLowerCase();
      if (!msg.includes('cancel') && !msg.includes('annul')) throw err;
    }
    return 'share';
  }

  // --- Web ---
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
  return 'download';
}

function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = reader.result;
      resolve(typeof result === 'string' ? result.split(',')[1] : '');
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}
