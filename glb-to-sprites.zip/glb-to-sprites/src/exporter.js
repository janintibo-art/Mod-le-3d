import JSZip from 'jszip';

/* =========================================================
   Modèle unifié : une "unité" = une animation × une direction.
     unit = { animation, direction, frames: Canvas[] }
   Fonctionne pour : 1 anim/1 dir, 1 anim/8 dir, toutes les
   animations, toutes les animations × 8 directions.
   ========================================================= */

/** Rogne les marges transparentes avec une boîte commune à TOUTES les unités. */
export function trimUnits(units, threshold = 0) {
  const source = { w: units[0].frames[0].width, h: units[0].frames[0].height };

  let minX = Infinity, minY = Infinity, maxX = -1, maxY = -1;
  for (const u of units) {
    for (const cv of u.frames) {
      const b = alphaBounds(cv, threshold);
      if (!b) continue;
      if (b.minX < minX) minX = b.minX;
      if (b.minY < minY) minY = b.minY;
      if (b.maxX > maxX) maxX = b.maxX;
      if (b.maxY > maxY) maxY = b.maxY;
    }
  }

  if (maxX < 0) {
    return { units, bbox: { x: 0, y: 0, w: source.w, h: source.h, source } };
  }

  const w = maxX - minX + 1;
  const h = maxY - minY + 1;
  const out = units.map((u) => ({
    animation: u.animation,
    direction: u.direction,
    frames: u.frames.map((cv) => cropCanvas(cv, minX, minY, w, h)),
  }));
  return { units: out, bbox: { x: minX, y: minY, w, h, source } };
}

function alphaBounds(canvas, threshold) {
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  const w = canvas.width;
  const h = canvas.height;
  const data = ctx.getImageData(0, 0, w, h).data;

  let minX = w, minY = h, maxX = -1, maxY = -1;
  for (let y = 0; y < h; y++) {
    const base = y * w * 4;
    let rowHas = false;
    for (let x = 0; x < w; x++) {
      if (data[base + x * 4 + 3] > threshold) {
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
        rowHas = true;
      }
    }
    if (rowHas) {
      if (y < minY) minY = y;
      if (y > maxY) maxY = y;
    }
  }
  if (maxX < 0) return null;
  return { minX, minY, maxX, maxY };
}

function cropCanvas(src, x, y, w, h) {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  c.getContext('2d').drawImage(src, x, y, w, h, 0, 0, w, h);
  return c;
}

function targetFor(zip, u, multiAnim, multiDir) {
  let t = zip;
  if (multiAnim) t = t.folder(u.animation);
  if (multiDir) t = t.folder(u.direction);
  return t;
}

/** ZIP d'images PNG. Dossiers par animation et/ou par direction selon les cas. */
export async function exportFramesZip(units, baseName) {
  const zip = new JSZip();
  const multiAnim = new Set(units.map((u) => u.animation)).size > 1;
  const multiDir = new Set(units.map((u) => u.direction)).size > 1;

  for (const u of units) {
    const target = targetFor(zip, u, multiAnim, multiDir);
    for (let i = 0; i < u.frames.length; i++) {
      const idx = String(i).padStart(3, '0');
      const blob = await canvasToBlob(u.frames[i]);
      target.file(`${baseName}_${u.animation}_${u.direction}_${idx}.png`, blob);
    }
  }
  return zip.generateAsync({ type: 'blob' });
}

/** Planche (sprite sheet) PNG + atlas JSON par unité, dans un ZIP. */
export async function exportSheetZip(units, baseName, meta) {
  const zip = new JSZip();
  const multiAnim = new Set(units.map((u) => u.animation)).size > 1;

  for (const u of units) {
    const { canvas, cellW, cellH, cols, rows, placements } = buildSheetCanvas(u.frames, meta.columns);
    const atlas = makeAtlas(u, cellW, cellH, cols, rows, placements, meta.bbox);
    const sheetBlob = await canvasToBlob(canvas);

    const target = multiAnim ? zip.folder(u.animation) : zip;
    const name = `${baseName}_${u.animation}_${u.direction}`;
    target.file(`${name}.png`, sheetBlob);
    target.file(`${name}.json`, JSON.stringify(atlas, null, 2));
  }
  return zip.generateAsync({ type: 'blob' });
}

function makeAtlas(u, cellW, cellH, cols, rows, placements, bbox) {
  const trimmed = !!bbox && (bbox.w !== bbox.source.w || bbox.h !== bbox.source.h);
  return {
    animation: u.animation,
    direction: u.direction,
    frameWidth: cellW,
    frameHeight: cellH,
    columns: cols,
    rows,
    frameCount: u.frames.length,
    trimmed,
    sourceSize: bbox ? { w: bbox.source.w, h: bbox.source.h } : { w: cellW, h: cellH },
    trim: bbox ? { x: bbox.x, y: bbox.y } : { x: 0, y: 0 },
    frames: placements,
  };
}

/** Compose la planche dans un canvas (réutilisé pour l'aperçu et Godot). */
export function buildSheetCanvas(frames, columns) {
  const cellW = frames[0].width;
  const cellH = frames[0].height;
  const cols = (columns && columns > 0) ? columns : Math.ceil(Math.sqrt(frames.length));
  const rows = Math.ceil(frames.length / cols);

  const canvas = document.createElement('canvas');
  canvas.width = cols * cellW;
  canvas.height = rows * cellH;
  const ctx = canvas.getContext('2d');

  const placements = [];
  for (let i = 0; i < frames.length; i++) {
    const x = (i % cols) * cellW;
    const y = Math.floor(i / cols) * cellH;
    ctx.drawImage(frames[i], x, y);
    placements.push({ index: i, x, y, w: cellW, h: cellH });
  }
  return { canvas, cellW, cellH, cols, rows, placements };
}

function canvasToBlob(canvas) {
  return new Promise((resolve) => canvas.toBlob(resolve, 'image/png'));
}
