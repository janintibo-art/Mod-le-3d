import JSZip from 'jszip';

/* =========================================================
   Les "frames" sont désormais des <canvas> 2D.
   - trimCaptures : rogne les marges transparentes (boîte commune).
   - exportFramesZip : images PNG séparées dans un ZIP.
   - exportSheetZip  : planche PNG + atlas JSON dans un ZIP.
   ========================================================= */

/**
 * Calcule une boîte englobante commune à TOUTES les images (toutes directions)
 * d'après l'alpha, puis recadre chaque image dessus.
 * Résultat : sprites compacts ET de taille uniforme, sans décalage.
 */
export function trimCaptures(captures, threshold = 0) {
  const source = {
    w: captures[0].frames[0].width,
    h: captures[0].frames[0].height,
  };

  let minX = Infinity, minY = Infinity, maxX = -1, maxY = -1;
  for (const cap of captures) {
    for (const cv of cap.frames) {
      const b = alphaBounds(cv, threshold);
      if (!b) continue;
      if (b.minX < minX) minX = b.minX;
      if (b.minY < minY) minY = b.minY;
      if (b.maxX > maxX) maxX = b.maxX;
      if (b.maxY > maxY) maxY = b.maxY;
    }
  }

  // Toutes les images vides : on ne rogne pas.
  if (maxX < 0) {
    return { captures, bbox: { x: 0, y: 0, w: source.w, h: source.h, source } };
  }

  const w = maxX - minX + 1;
  const h = maxY - minY + 1;
  const out = captures.map((cap) => ({
    direction: cap.direction,
    frames: cap.frames.map((cv) => cropCanvas(cv, minX, minY, w, h)),
  }));

  return { captures: out, bbox: { x: minX, y: minY, w, h, source } };
}

function alphaBounds(canvas, threshold) {
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  const w = canvas.width;
  const h = canvas.height;
  const data = ctx.getImageData(0, 0, w, h).data;

  let minX = w, minY = h, maxX = -1, maxY = -1;
  for (let y = 0; y < h; y++) {
    const base = y * w * 4;
    let rowHas = false;
    for (let x = 0; x < w; x++) {
      if (data[base + x * 4 + 3] > threshold) {
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
        rowHas = true;
      }
    }
    if (rowHas) {
      if (y < minY) minY = y;
      if (y > maxY) maxY = y;
    }
  }
  if (maxX < 0) return null;
  return { minX, minY, maxX, maxY };
}

function cropCanvas(src, x, y, w, h) {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  c.getContext('2d').drawImage(src, x, y, w, h, 0, 0, w, h);
  return c;
}

/** ZIP d'images PNG (un dossier par direction si plusieurs). */
export async function exportFramesZip(captures, baseName) {
  const zip = new JSZip();
  const single = captures.length === 1;

  for (const cap of captures) {
    const target = single ? zip : zip.folder(cap.direction);
    for (let i = 0; i < cap.frames.length; i++) {
      const idx = String(i).padStart(3, '0');
      const blob = await canvasToBlob(cap.frames[i]);
      target.file(`${baseName}_${cap.direction}_${idx}.png`, blob);
    }
  }
  return zip.generateAsync({ type: 'blob' });
}

/** Planche (sprite sheet) PNG + atlas JSON par direction, dans un ZIP. */
export async function exportSheetZip(captures, baseName, meta) {
  const zip = new JSZip();
  const single = captures.length === 1;

  for (const cap of captures) {
    const { sheetBlob, atlas } = await buildSheet(cap.frames, meta.columns, {
      animation: meta.animation,
      direction: cap.direction,
      bbox: meta.bbox,
    });
    const target = single ? zip : zip.folder(cap.direction);
    target.file(`${baseName}_${cap.direction}.png`, sheetBlob);
    target.file(`${baseName}_${cap.direction}.json`, JSON.stringify(atlas, null, 2));
  }
  return zip.generateAsync({ type: 'blob' });
}

/** Compose la planche dans un canvas (réutilisé pour l'aperçu). */
export function buildSheetCanvas(frames, columns) {
  const cellW = frames[0].width;
  const cellH = frames[0].height;
  const cols = (columns && columns > 0) ? columns : Math.ceil(Math.sqrt(frames.length));
  const rows = Math.ceil(frames.length / cols);

  const canvas = document.createElement('canvas');
  canvas.width = cols * cellW;
  canvas.height = rows * cellH;
  const ctx = canvas.getContext('2d');

  const placements = [];
  for (let i = 0; i < frames.length; i++) {
    const x = (i % cols) * cellW;
    const y = Math.floor(i / cols) * cellH;
    ctx.drawImage(frames[i], x, y);
    placements.push({ index: i, x, y, w: cellW, h: cellH });
  }
  return { canvas, cellW, cellH, cols, rows, placements };
}

async function buildSheet(frames, columns, info) {
  const { canvas, cellW, cellH, cols, rows, placements } = buildSheetCanvas(frames, columns);

  const bbox = info.bbox;
  const trimmed = !!bbox && (bbox.w !== bbox.source.w || bbox.h !== bbox.source.h);

  const atlas = {
    animation: info.animation,
    direction: info.direction,
    frameWidth: cellW,
    frameHeight: cellH,
    columns: cols,
    rows,
    frameCount: frames.length,
    trimmed,
    sourceSize: bbox ? { w: bbox.source.w, h: bbox.source.h } : { w: cellW, h: cellH },
    trim: bbox ? { x: bbox.x, y: bbox.y } : { x: 0, y: 0 },
    frames: placements,
  };

  const sheetBlob = await canvasToBlob(canvas);
  return { sheetBlob, atlas };
}

function canvasToBlob(canvas) {
  return new Promise((resolve) => canvas.toBlob(resolve, 'image/png'));
}
