import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';

// Vecteurs de direction (avant que la caméra ne s'éloigne du modèle).
const DIRECTIONS = {
  'front':       new THREE.Vector3(0, 0, 1),
  'front-right': new THREE.Vector3(1, 0, 1),
  'right':       new THREE.Vector3(1, 0, 0),
  'back-right':  new THREE.Vector3(1, 0, -1),
  'back':        new THREE.Vector3(0, 0, -1),
  'back-left':   new THREE.Vector3(-1, 0, -1),
  'left':        new THREE.Vector3(-1, 0, 0),
  'front-left':  new THREE.Vector3(-1, 0, 1),
  'top':         new THREE.Vector3(0, 1, 0.0001),
};

export const ALL_DIRECTIONS = [
  'front', 'front-right', 'right', 'back-right',
  'back', 'back-left', 'left', 'front-left',
];

// Textures concernées par le filtrage (mode pixel-art).
const TEX_KEYS = ['map', 'emissiveMap', 'normalMap', 'roughnessMap', 'metalnessMap', 'aoMap', 'alphaMap'];

export class SpriteRenderer {
  constructor(container) {
    this.container = container;
    this.size = 256;
    this.framing = 1.3;
    this.elevationDeg = 0;
    this.direction = 'front';
    this.bgColor = null;   // null => fond transparent
    this.pixelArt = false;

    this.renderer = null;
    this._createRenderer();

    this.scene = new THREE.Scene();
    this.camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0.01, 5000);

    // Éclairage neutre : lecture claire des couleurs du modèle.
    this.scene.add(new THREE.HemisphereLight(0xffffff, 0x404050, 1.15));
    const key = new THREE.DirectionalLight(0xffffff, 1.6);
    key.position.set(3, 5, 4);
    this.scene.add(key);
    const fill = new THREE.DirectionalLight(0xffffff, 0.5);
    fill.position.set(-4, 2, -3);
    this.scene.add(fill);

    this.model = null;
    this.mixer = null;
    this.clips = [];
    this.center = new THREE.Vector3();
    this.sizeVec = new THREE.Vector3(1, 1, 1);

    this._clock = new THREE.Clock();
    this._previewClip = null;
    this._raf = null;
  }

  // L'anti-aliasing se fixe à la création : on recrée le renderer pour basculer.
  _createRenderer() {
    if (this.renderer) {
      this.renderer.dispose();
      try { this.renderer.forceContextLoss(); } catch (_e) { /* ignore */ }
      if (this.renderer.domElement && this.renderer.domElement.parentNode) {
        this.renderer.domElement.remove();
      }
    }
    this.renderer = new THREE.WebGLRenderer({
      alpha: true,
      antialias: !this.pixelArt,
      preserveDrawingBuffer: true,
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.setPixelRatio(1);
    this.renderer.setSize(this.size, this.size, false);
    this.renderer.domElement.style.imageRendering = this.pixelArt ? 'pixelated' : 'auto';
    this._applyClear();
    this.container.appendChild(this.renderer.domElement);
  }

  _applyClear() {
    if (this.bgColor === null) {
      this.renderer.setClearColor(0x000000, 0);
    } else {
      this.renderer.setClearColor(new THREE.Color(this.bgColor), 1);
    }
  }

  /** Charge un ArrayBuffer (.glb/.gltf binaire). Renvoie la liste des clips. */
  load(arrayBuffer) {
    return new Promise((resolve, reject) => {
      const loader = new GLTFLoader();
      loader.parse(
        arrayBuffer,
        '',
        (gltf) => {
          try {
            this._setModel(gltf);
            resolve({
              hasAnimations: this.clips.length > 0,
              clips: this.clips.map((c) => ({ name: c.name || 'clip', duration: c.duration })),
              dims: { x: this.sizeVec.x, y: this.sizeVec.y, z: this.sizeVec.z },
            });
          } catch (err) {
            reject(err);
          }
        },
        reject
      );
    });
  }

  _setModel(gltf) {
    if (this.model) this.scene.remove(this.model);
    this.model = gltf.scene;
    this.clips = gltf.animations || [];
    this.scene.add(this.model);
    this.mixer = new THREE.AnimationMixer(this.model);

    const box = new THREE.Box3().setFromObject(this.model);
    box.getCenter(this.center);
    box.getSize(this.sizeVec);
    this._setTextureFiltering(this.pixelArt);
    this._updateCamera();
  }

  setSize(px)        { this.size = px; this.renderer.setSize(px, px, false); this._updateCamera(); this._renderOnce(); }
  setFraming(mult)   { this.framing = mult; this._updateCamera(); this._renderOnce(); }
  setElevation(deg)  { this.elevationDeg = deg; this._updateCamera(); this._renderOnce(); }
  setDirection(dir)  { this.direction = dir; this._updateCamera(); this._renderOnce(); }
  setBackground(c)   { this.bgColor = c; this._applyClear(); this._renderOnce(); }

  setPixelArt(on) {
    this.pixelArt = !!on;
    this.stopPreview();
    this._createRenderer();
    this._setTextureFiltering(this.pixelArt);
    this._renderOnce();
  }

  _setTextureFiltering(pixel) {
    if (!this.model) return;
    this.model.traverse((o) => {
      if (!o.isMesh) return;
      const mats = Array.isArray(o.material) ? o.material : [o.material];
      mats.forEach((m) => {
        if (!m) return;
        for (const key of TEX_KEYS) {
          const tex = m[key];
          if (!tex) continue;
          if (!tex.userData.__orig) {
            tex.userData.__orig = { mag: tex.magFilter, min: tex.minFilter, mips: tex.generateMipmaps };
          }
          if (pixel) {
            tex.magFilter = THREE.NearestFilter;
            tex.minFilter = THREE.NearestFilter;
            tex.generateMipmaps = false;
          } else {
            tex.magFilter = tex.userData.__orig.mag;
            tex.minFilter = tex.userData.__orig.min;
            tex.generateMipmaps = tex.userData.__orig.mips;
          }
          tex.needsUpdate = true;
        }
      });
    });
  }

  _dirVector(dir, elevationDeg) {
    const base = (DIRECTIONS[dir] || DIRECTIONS.front).clone();
    if (dir === 'top') return base.normalize();
    base.y = 0;
    if (base.lengthSq() === 0) base.set(0, 0, 1);
    base.normalize();
    const e = THREE.MathUtils.degToRad(elevationDeg);
    const v = base.multiplyScalar(Math.cos(e));
    v.y += Math.sin(e);
    return v.normalize();
  }

  _updateCamera() {
    if (!this.model) return;
    const maxXY = Math.max(this.sizeVec.x, this.sizeVec.y) || 1;
    const half = (maxXY / 2) * this.framing;
    this.camera.left = -half;
    this.camera.right = half;
    this.camera.top = half;
    this.camera.bottom = -half;

    const dist = (this.sizeVec.length() || 1) * 2 + 10;
    const dir = this._dirVector(this.direction, this.elevationDeg);
    this.camera.position.copy(this.center).addScaledVector(dir, dist);
    this.camera.up.set(0, 1, 0);
    this.camera.lookAt(this.center);
    this.camera.near = 0.01;
    this.camera.far = dist * 4;
    this.camera.updateProjectionMatrix();
  }

  _renderOnce() {
    if (this.model) this.renderer.render(this.scene, this.camera);
  }

  /** Copie l'image courante du WebGL vers un canvas 2D (lecture de pixels possible). */
  _grabCanvas() {
    const c = document.createElement('canvas');
    c.width = this.size;
    c.height = this.size;
    const ctx = c.getContext('2d', { willReadFrequently: true });
    ctx.drawImage(this.renderer.domElement, 0, 0, this.size, this.size);
    return c;
  }

  /** Aperçu temps réel du clip choisi (boucle requestAnimationFrame). */
  startPreview(clipName) {
    this.stopPreview();
    if (this.mixer) this.mixer.stopAllAction();
    this._previewClip = null;

    if (clipName) {
      const clip = this.clips.find((c) => (c.name || 'clip') === clipName);
      if (clip && this.mixer) {
        const action = this.mixer.clipAction(clip);
        action.reset();
        action.play();
        this._previewClip = clip;
      }
    }
    this._clock.start();
    const loop = () => {
      this._raf = requestAnimationFrame(loop);
      const dt = this._clock.getDelta();
      if (this.mixer && this._previewClip) this.mixer.update(dt);
      this._renderOnce();
    };
    loop();
  }

  stopPreview() {
    if (this._raf) { cancelAnimationFrame(this._raf); this._raf = null; }
  }

  /**
   * Capture déterministe des images d'un clip dans la direction actuelle.
   * Renvoie un tableau de canvas 2D (pour permettre le rognage).
   * Échantillonne sur [0, durée) pour une boucle sans doublon.
   */
  async capture(clipName, frameCount) {
    this.stopPreview();
    if (this.mixer) this.mixer.stopAllAction();

    let clip = null;
    if (clipName) clip = this.clips.find((c) => (c.name || 'clip') === clipName);

    const frames = [];

    if (!clip) {
      this._renderOnce();
      frames.push(this._grabCanvas());
      return { frames, width: this.size, height: this.size };
    }

    const action = this.mixer.clipAction(clip);
    action.reset();
    action.play();

    const n = Math.max(1, frameCount | 0);
    for (let i = 0; i < n; i++) {
      const t = (i / n) * clip.duration;
      this.mixer.setTime(t);                          // pose exacte au temps t
      this.renderer.render(this.scene, this.camera);
      frames.push(this._grabCanvas());
    }
    action.stop();
    return { frames, width: this.size, height: this.size };
  }
}
