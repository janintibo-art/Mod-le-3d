import { GIFEncoder, quantize, applyPalette } from 'gifenc';

/**
 * Encode un tableau de <canvas> en GIF animé (Blob).
 *  - delayMs : durée d'affichage de chaque image.
 *  - Gère la transparence en 1 bit (limite du format GIF) : si le fond est
 *    transparent, les pixels transparents deviennent l'index transparent.
 *    Pour un GIF parfaitement net, utilise un fond de couleur unie.
 */
export function framesToGif(frames, delayMs) {
  const w = frames[0].width;
  const h = frames[0].height;
  const delay = Math.max(20, Math.round(delayMs || 80));
  const format = 'rgba4444';

  const enc = GIFEncoder();

  for (let i = 0; i < frames.length; i++) {
    const ctx = frames[i].getContext('2d', { willReadFrequently: true });
    const rgba = ctx.getImageData(0, 0, w, h).data;

    const palette = quantize(rgba, 256, { format, oneBitAlpha: true });
    const index = applyPalette(rgba, palette, format);
    const transparentIndex = findTransparentIndex(palette);

    const opts = { palette, delay, dispose: 2 };
    if (i === 0) opts.repeat = 0; // boucle infinie
    if (transparentIndex >= 0) {
      opts.transparent = true;
      opts.transparentIndex = transparentIndex;
    }
    enc.writeFrame(index, w, h, opts);
  }

  enc.finish();
  return new Blob([enc.bytes()], { type: 'image/gif' });
}

function findTransparentIndex(palette) {
  for (let i = 0; i < palette.length; i++) {
    const c = palette[i];
    if (c && c.length >= 4 && c[3] === 0) return i;
  }
  return -1;
}
