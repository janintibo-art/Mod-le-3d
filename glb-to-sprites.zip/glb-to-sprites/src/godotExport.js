import JSZip from 'jszip';
import { buildSheetCanvas } from './exporter.js';

/* =========================================================
   Génère UNE ressource Godot 4 SpriteFrames (.tres) contenant
   toutes les unités (animation × direction) + les planches PNG.
   Ex. d'animations : idle_front, walk_front, run_front, walk_right…
   ========================================================= */

let _counter = 0;
function token() {
  _counter += 1;
  return _counter.toString(36) + Math.random().toString(36).slice(2, 6);
}

export async function exportGodotZip(units, baseName, meta, onProgress) {
  const zip = new JSZip();
  const folder = meta.folder;
  const entries = [];
  const total = units.length;
  let done = 0;

  for (const u of units) {
    const { canvas, placements } = buildSheetCanvas(u.frames, meta.columns);
    const pngName = `${u.animation}_${u.direction}.png`;
    const blob = await new Promise((r) => canvas.toBlob(r, 'image/png'));
    zip.folder(folder).file(pngName, blob);

    const dur = (meta.durations && meta.durations[u.animation]) || 0;
    const n = u.frames.length;
    const fps = (n > 1 && dur > 0) ? n / dur : (meta.defaultFps || 12);

    entries.push({
      animName: `${u.animation}_${u.direction}`,
      pngName,
      frames: placements,
      fps,
      loop: n > 1,
    });

    done += 1;
    if (onProgress) {
      onProgress(done, total);
      await new Promise((r) => setTimeout(r));
    }
  }

  const tres = buildTres(entries, folder);
  zip.folder(folder).file(`${baseName}.tres`, tres);
  zip.folder(folder).file('LISEZ-MOI.txt', readme(folder, entries));

  return zip.generateAsync({ type: 'blob', streamFiles: true });
}

function buildTres(entries, folder) {
  const ext = [];
  const sub = [];
  const anims = [];
  let extIndex = 0;
  let totalFrames = 0;

  for (const e of entries) {
    extIndex += 1;
    const extId = `${extIndex}_${token()}`;
    ext.push(`[ext_resource type="Texture2D" path="res://${folder}/${e.pngName}" id="${extId}"]`);

    const frameItems = [];
    for (const r of e.frames) {
      const subId = `AtlasTexture_${token()}`;
      sub.push(
        `[sub_resource type="AtlasTexture" id="${subId}"]\n` +
        `atlas = ExtResource("${extId}")\n` +
        `region = Rect2(${r.x}, ${r.y}, ${r.w}, ${r.h})`
      );
      frameItems.push(`{
"duration": 1.0,
"texture": SubResource("${subId}")
}`);
      totalFrames += 1;
    }

    anims.push(`{
"frames": [${frameItems.join(', ')}],
"loop": ${e.loop ? 'true' : 'false'},
"name": &"${e.animName}",
"speed": ${e.fps.toFixed(3)}
}`);
  }

  const loadSteps = entries.length + totalFrames + 1;

  return (
    `[gd_resource type="SpriteFrames" load_steps=${loadSteps} format=3]\n\n` +
    ext.join('\n') + '\n\n' +
    sub.join('\n\n') + '\n\n' +
    '[resource]\n' +
    `animations = [${anims.join(', ')}]\n`
  );
}

function readme(folder, entries) {
  const names = entries.slice(0, 6).map((e) => e.animName);
  const example = names[0] || 'anim';
  return [
    'Dossier SpriteFrames pour Godot 4.',
    '',
    `1. Copie CE dossier entier ("${folder}") a la racine de ton projet Godot`,
    `   (il doit donner res://${folder}/...).`,
    '2. Godot importe les PNG automatiquement.',
    '3. Glisse le .tres sur un noeud AnimatedSprite2D (propriete "Sprite Frames"),',
    '   ou charge-le par code : load("res://' + folder + '/...tres").',
    `4. Choisis l'animation via la propriete "animation".`,
    '',
    `Animations incluses (${entries.length}) : ${names.join(', ')}${entries.length > 6 ? ', ...' : ''}`,
    `Exemple de lecture : $AnimatedSprite2D.play("${example}")`,
    '',
    `Les chemins du .tres pointent vers res://${folder}/*.png :`,
    'ne renomme pas le dossier sans mettre a jour les chemins dans le .tres.',
    '',
  ].join('\n');
}
