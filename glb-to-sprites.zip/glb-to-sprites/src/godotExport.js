import JSZip from 'jszip';
import { buildSheetCanvas } from './exporter.js';

/* =========================================================
   Génère une ressource Godot 4 SpriteFrames (.tres) + les
   planches PNG, le tout dans un ZIP.
   - 1 animation par direction (ex. "walk_front", "walk_right"…).
   - Chaque image = AtlasTexture (région) dans la planche.
   ========================================================= */

let _counter = 0;
function token() {
  _counter += 1;
  return _counter.toString(36) + Math.random().toString(36).slice(2, 6);
}

export async function exportGodotZip(captures, baseName, meta) {
  const zip = new JSZip();
  const folder = meta.folder;
  const dirMeta = [];

  for (const cap of captures) {
    const { canvas, placements } = buildSheetCanvas(cap.frames, meta.columns);
    const pngName = `${meta.animation}_${cap.direction}.png`;
    const blob = await new Promise((r) => canvas.toBlob(r, 'image/png'));
    zip.folder(folder).file(pngName, blob);
    dirMeta.push({ direction: cap.direction, pngName, frames: placements });
  }

  const tres = buildTres(dirMeta, folder, meta.animation, meta.fps, meta.loop);
  zip.folder(folder).file(`${baseName}_${meta.animation}.tres`, tres);
  zip.folder(folder).file('LISEZ-MOI.txt', readme(folder, meta.animation));

  return zip.generateAsync({ type: 'blob' });
}

function buildTres(dirMeta, folder, animName, fps, loop) {
  const ext = [];
  const sub = [];
  const anims = [];
  let extIndex = 0;

  for (const d of dirMeta) {
    extIndex += 1;
    const extId = `${extIndex}_${token()}`;
    ext.push(`[ext_resource type="Texture2D" path="res://${folder}/${d.pngName}" id="${extId}"]`);

    const frameItems = [];
    for (const r of d.frames) {
      const subId = `AtlasTexture_${token()}`;
      sub.push(
        `[sub_resource type="AtlasTexture" id="${subId}"]\n` +
        `atlas = ExtResource("${extId}")\n` +
        `region = Rect2(${r.x}, ${r.y}, ${r.w}, ${r.h})`
      );
      frameItems.push(`{
"duration": 1.0,
"texture": SubResource("${subId}")
}`);
    }

    anims.push(`{
"frames": [${frameItems.join(', ')}],
"loop": ${loop ? 'true' : 'false'},
"name": &"${animName}_${d.direction}",
"speed": ${fps.toFixed(3)}
}`);
  }

  const totalFrames = dirMeta.reduce((s, d) => s + d.frames.length, 0);
  const loadSteps = dirMeta.length + totalFrames + 1;

  return (
    `[gd_resource type="SpriteFrames" load_steps=${loadSteps} format=3]\n\n` +
    ext.join('\n') + '\n\n' +
    sub.join('\n\n') + '\n\n' +
    '[resource]\n' +
    `animations = [${anims.join(', ')}]\n`
  );
}

function readme(folder, animName) {
  return [
    'Dossier SpriteFrames pour Godot 4.',
    '',
    `1. Copie CE dossier entier ("${folder}") a la racine de ton projet Godot`,
    `   (il doit donner res://${folder}/...).`,
    '2. Godot importe les PNG automatiquement.',
    '3. Glisse le .tres sur un noeud AnimatedSprite2D (propriete "Sprite Frames"),',
    '   ou charge-le par code : load("res://' + folder + '/...tres").',
    `4. Choisis l'animation (ex. "${animName}_front") via la propriete "animation".`,
    '',
    `Les chemins du .tres pointent vers res://${folder}/*.png :`,
    'ne renomme pas le dossier sans mettre a jour les chemins dans le .tres.',
    '',
  ].join('\n');
}
