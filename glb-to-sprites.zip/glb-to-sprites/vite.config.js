import { defineConfig } from 'vite';

// base: './'  => chemins relatifs, indispensable pour charger les assets
// depuis le fichier:// du WebView Android (Capacitor).
export default defineConfig({
  base: './',
  build: {
    outDir: 'dist',
    target: 'es2020',
  },
});
